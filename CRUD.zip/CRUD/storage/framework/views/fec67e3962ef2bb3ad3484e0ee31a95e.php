<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>  
</head>
<body>
    <div style="margin: 150px">
    <h1 align="center">Edit</h1>
    <form action="<?php echo e(route('product.update',['product' => $product])); ?>" method="post" class="form-control" style="text-align : center;">
        
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <table class="table table-striped">
            <tr><td>
            <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control">
            </td>
            </tr>
            <tr><td>
            <input type="number" name="qty" value="<?php echo e($product->qty); ?>" class="form-control">
            </td>
            </tr>
            <tr><td>
            <input type="number" name="price" value="<?php echo e($product->price); ?>" class="form-control"><br>
            </td>
            </tr>
            <tr><td>
            <input type="submit" name="submit" value="Update" class="btn btn-danger" >
            </td>
            </tr>
        </table>
    </form>
</body>
</html><?php /**PATH D:\RCSS\Sem 2\Laravel\CRUD\resources\views/products/edit.blade.php ENDPATH**/ ?>